# Remote-Database-to-Optimize-DigitalOcean-
How To Set Up a Remote Database to Optimize Site Performance with MySQL
